# Archived

This repository has been archived.  
All textures, models and language files are now included with [Nova](https://github.com/xenondevs/Nova) and the [addons themselves](https://github.com/Nova-Addons).

## NovaRP
The resource pack for [Nova](https://github.com/xenondevs/Nova)

## Credits
Gear Textures by legitbox#8259
