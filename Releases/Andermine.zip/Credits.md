This Resource pack is the cumulative work of M3RGeo, MagmaGuy, Xenondevs and Kunfury.

- **M3RGeo** - Merged the three Resource packs mentioned underneath this entry and added/improved some textures/models.
- **MagmaGuy** - Elitemobs Resource pack 
- **Kunfury** - Blep Fishing Resource pack
- **Xenondevs** - NovaRP Resource pack of which the GUI models and Resources were used.

# Links:
**Elitemobs Resource pack:**
https://magmaguy.itch.io/em-free-content

**Blep Fishing Resource pack:**
https://www.planetminecraft.com/Resource-pack/blep-fishing-resources/

**NovaRP Resource pack:**
https://github.com/xenondevs/NovaRP